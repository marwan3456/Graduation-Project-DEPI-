import org.openqa.selenium.WebDriver;

public class Create_account extends Page_Base{

    public Create_account(WebDriver driver) {
        super(driver);
    }
}
