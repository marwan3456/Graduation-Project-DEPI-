
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

    public class Test_Base {
        WebDriver driver;
        @BeforeMethod
        public void open_chrome(){
            driver = new ChromeDriver();
            //how to maximize the screen
            driver.manage().window().maximize();
            driver.navigate().to("https://automationexercise.com/signup");
            signup_page signup = new signup_page(driver);
            signup.valid_name();
            signup.valid_email();
            signup.signupbutton();
        }
        @AfterMethod
        public void close_chrome() throws InterruptedException {
            Thread.sleep(6000);
            driver.quit();
        }
    }


