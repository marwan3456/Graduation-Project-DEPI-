import org.testng.Assert;
import org.testng.annotations.Test;

public class create_account_test extends Test_Base {

    // ----------------- Helper to fill all fields -----------------
    public create_account fillAllRequiredFields() {
        create_account ca = new create_account(driver);
        String testEmail = "testuser" + System.currentTimeMillis() + "@gmail.com";

        ca.signUpPage(
                "Mr",
                "Test User",
                testEmail,
                "Test12345",
                "10", "May", "1998",
                "Test", "User", "ABC Corp",
                "Street 22", "Building 3",
                "India", "Delhi", "Delhi",
                "110001", "0123456789",
                true, true
        );
        return ca;
    }

    // ----------------- 1) Valid Account Creation -----------------
    @Test(priority = 1)
    public void validAccountCreation() {
        create_account ca = fillAllRequiredFields();
        Assert.assertTrue(driver.getCurrentUrl().contains("account_created"));
    }

    // ----------------- 2) Empty Name -----------------
    @Test(priority = 2)
    public void emptyNameTest() {
        create_account ca = new create_account(driver);

        ca.signUpPage(
                "Mr",
                "",
                "testempty" + System.currentTimeMillis() + "@gmail.com",
                "Test12345",
                "10", "May", "1998",
                "Test", "User", "ABC Corp",
                "Street 22", "Building 3",
                "India", "Delhi", "Delhi",
                "110001", "0123456789",
                true, true
        );

        Assert.assertTrue(driver.getPageSource().contains("required"));
    }

    // ----------------- 3) Empty Password -----------------
    @Test(priority = 3)
    public void emptyPasswordTest() {
        create_account ca = new create_account(driver);

        ca.signUpPage(
                "Mr",
                "Test User",
                "emptypass" + System.currentTimeMillis() + "@gmail.com",
                "",
                "10", "May", "1998",
                "Test", "User", "ABC Corp",
                "Street 22", "Building 3",
                "India", "Delhi", "Delhi",
                "110001", "0123456789",
                true, true
        );

        Assert.assertTrue(driver.getPageSource().contains("required"));
    }

    // ----------------- 4) Select Mrs -----------------
    @Test(priority = 4)
    public void selectMrsTest() {
        create_account ca = new create_account(driver);

        fillAllRequiredFields();
        ca.chooseTitle("Mrs");

        Assert.assertTrue(driver.findElement(ca.title_mrs).isSelected());
    }

    // ----------------- 5) Select Mr -----------------
    @Test(priority = 5)
    public void selectMrTest() {
        create_account ca = new create_account(driver);

        fillAllRequiredFields();
        ca.chooseTitle("Mr");

        Assert.assertTrue(driver.findElement(ca.title_mr).isSelected());
    }

    // ----------------- 6) Newsletter Checkbox -----------------
    @Test(priority = 6)
    public void newsletterSelection() {
        create_account ca = new create_account(driver);

        fillAllRequiredFields();
        ca.Click_On_button(ca.newsletter);

        Assert.assertTrue(driver.findElement(ca.newsletter).isSelected());
    }

    // ----------------- 7) Offers Checkbox -----------------
    @Test(priority = 7)
    public void offersSelection() {
        create_account ca = new create_account(driver);

        fillAllRequiredFields();
        ca.Click_On_button(ca.offers);

        Assert.assertTrue(driver.findElement(ca.offers).isSelected());
    }

    // ----------------- 8) Empty Mobile -----------------
    @Test(priority = 8)
    public void emptyMobileTest() {
        create_account ca = new create_account(driver);

        ca.signUpPage(
                "Mr",
                "Test User",
                "emptymobile" + System.currentTimeMillis() + "@gmail.com",
                "Test12345",
                "10", "May", "1998",
                "Test", "User", "ABC Corp",
                "Street 22", "Building 3",
                "India", "Delhi", "Delhi",
                "110001", "",
                true, true
        );

        Assert.assertTrue(driver.getPageSource().contains("required"));
    }

    // ----------------- 9) Invalid Zipcode -----------------
    @Test(priority = 9)
    public void invalidZipcodeTest() {
        create_account ca = new create_account(driver);

        ca.signUpPage(
                "Mr",
                "Test User",
                "invalidzip" + System.currentTimeMillis() + "@gmail.com",
                "Test12345",
                "10", "May", "1998",
                "Test", "User", "ABC Corp",
                "Street 22", "Building 3",
                "India", "Delhi", "Delhi",
                "ABCDE", "0123456789",
                true, true
        );

        Assert.assertTrue(driver.getPageSource().contains("postcode"));
    }

    // ----------------- 10) Create Button Visible -----------------
    @Test(priority = 10)
    public void createButtonVisibleTest() {
        create_account ca = new create_account(driver);
        fillAllRequiredFields();

        Assert.assertTrue(driver.findElement(ca.createBtn).isDisplayed());
    }
}
