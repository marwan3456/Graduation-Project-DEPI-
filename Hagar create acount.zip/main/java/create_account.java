import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class create_account extends Page_Base {

    public create_account(WebDriver driver) {
        super(driver);
    }

    // ------- Locators -------
    public By title_mr = By.id("id_gender1");
    public By title_mrs = By.id("id_gender2");

    public By name = By.id("customer_firstname");
    public By email = By.id("email");
    public By password = By.id("passwd");

    public By day = By.id("days");
    public By month = By.id("months");
    public By year = By.id("years");

    public By newsletter = By.id("newsletter");
    public By offers = By.id("optin");

    public By firstName = By.id("firstname");
    public By lastName = By.id("lastname");
    public By company = By.id("company");
    public By address = By.id("address1");
    public By address2 = By.id("address2");
    public By country = By.id("id_country");
    public By state = By.id("id_state");
    public By city = By.id("city");
    public By zipcode = By.id("postcode");
    public By phone = By.id("phone_mobile");

    public By createBtn = By.id("submitAccount");

    // -------- Actions --------

    public void chooseTitle(String t) {
        waitForClickable(title_mr); // انتظار للتأكد أن العنصر clickable
        if (t.equalsIgnoreCase("Mr")) {
            Click_On_button(title_mr);
        } else {
            Click_On_button(title_mrs);
        }
    }

    public void fillBasicInfo(String fullName, String emailTxt, String pass) {
        waitForVisible(name);
        Enter_text(name, fullName);
        Enter_text(email, emailTxt);
        Enter_text(password, pass);
    }

    public void selectDOB(String d, String m, String y) {
        waitForVisible(day);
        Select_by_visible(day, d);
        Select_by_visible(month, m);
        Select_by_visible(year, y);
    }

    public void fillAddressInfo(String f, String l, String comp, String add1, String add2,
                                String countryName, String s, String c, String zip, String mobile) {

        waitForVisible(firstName);
        Enter_text(firstName, f);
        Enter_text(lastName, l);
        Enter_text(company, comp);
        Enter_text(address, add1);
        Enter_text(address2, add2);

        Select_by_visible(country, countryName);

        // state يمكن تكون dropdown أو input
        try {
            Select_by_visible(state, s);
        } catch (Exception e) {
            Enter_text(state, s);
        }

        Enter_text(city, c);
        Enter_text(zipcode, zip);
        Enter_text(phone, mobile);
    }

    public void clickCreate() {
        waitForClickable(createBtn);
        Click_On_button(createBtn);
    }

    // ------ Full Sign Up Function ------
    public void signUpPage(
            String title, String fullName, String emailTxt, String pass,
            String d, String m, String y,
            String f, String l, String comp, String add1, String add2,
            String countryName, String s, String c, String zip, String mobile,
            boolean news, boolean offer) {

        chooseTitle(title);
        fillBasicInfo(fullName, emailTxt, pass);
        selectDOB(d, m, y);

        if (news) Click_On_button(newsletter);
        if (offer) Click_On_button(offers);

        fillAddressInfo(f, l, comp, add1, add2, countryName, s, c, zip, mobile);

        clickCreate();
    }

    // -------- Helpers --------
    private void waitForVisible(By element) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOfElementLocated(element));
    }

    private void waitForClickable(By element) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.elementToBeClickable(element));
    }

    // -------- Dropdown helper --------
    public void Select_by_visible(By element, String value) {
        Select sel = new Select(driver.findElement(element));
        sel.selectByVisibleText(value);
    }
}
