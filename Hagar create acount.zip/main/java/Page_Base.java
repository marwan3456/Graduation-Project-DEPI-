import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class Page_Base {

    WebDriver driver;

    public Page_Base(WebDriver driver){
        this.driver = driver;
    }

    public Page_Base() {}

    // ---------------- Basic Actions ----------------

    public void Enter_text(By elementlocator , String text){
        wait1(elementlocator);
        driver.findElement(elementlocator).clear();
        driver.findElement(elementlocator).sendKeys(text);
    }

    public void Click_On_button(By elementlocator){
        wait1(elementlocator);
        driver.findElement(elementlocator).click();
    }

    // اختصار لكليك عشان نستخدمه كتير
    public void Click(By locator){
        wait1(locator);
        driver.findElement(locator).click();
    }

    // ---------------- Wait Function ----------------

    public void wait1(By elementlocator){
        new WebDriverWait(driver , Duration.ofSeconds(20))
                .until(ExpectedConditions.visibilityOfElementLocated(elementlocator));
    }

    // ---------------- Dropdown Functions ----------------

    public void Select_by_index(By elementlocator , int index){
        wait1(elementlocator);
        Select select = new Select(driver.findElement(elementlocator));
        select.selectByIndex(index);
    }

    public void Select_by_value(By elementlocator , String value){
        wait1(elementlocator);
        Select select = new Select(driver.findElement(elementlocator));
        select.selectByValue(value);
    }

    public void Select_by_visible(By elementlocator , String visible){
        wait1(elementlocator);
        Select select = new Select(driver.findElement(elementlocator));
        select.selectByVisibleText(visible);
    }

    // function موحدة نستخدمها في Create_Account_Page
    public void SelectFromList(By elementlocator , String visibleTxt){
        wait1(elementlocator);
        Select select = new Select(driver.findElement(elementlocator));
        select.selectByVisibleText(visibleTxt);
    }

    // ---------------- Extra Helper Functions ----------------

    public String Get_Text(By locator){
        wait1(locator);
        return driver.findElement(locator).getText();
    }

    public boolean element_is_displayed(By locator){
        try {
            wait1(locator);
            return driver.findElement(locator).isDisplayed();
        } catch (Exception e){
            return false;
        }
    }
}
